# TODO List Web Application

一个带 Web 界面的 TODO List 应用，使用 Flask 构建。

## 功能

- ✅ 查看任务列表
- ✅ 添加新任务
- ✅ 标记任务完成/未完成
- ✅ 删除任务
- ✅ 任务数据持久化（JSON 文件）

## 快速启动

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 运行应用
python app.py

# 3. 在浏览器打开
# http://localhost:8001
```

## 项目结构

```
todo-app/
├── app.py              # Flask 后端 API
├── requirements.txt    # Python 依赖
├── todos.json          # 任务数据存储（运行时自动生成）
└── templates/
    └── index.html      # 前端界面
```

## API 端点

| 方法 | 端点 | 说明 |
|------|------|------|
| GET | /api/tasks | 获取所有任务 |
| POST | /api/tasks | 添加新任务 |
| PUT | /api/tasks/<id> | 切换任务完成状态 |
| DELETE | /api/tasks/<id> | 删除任务 |

## 技术栈

- **后端**：Flask 3.0+
- **前端**：HTML + CSS + JavaScript（原生）
- **数据存储**：JSON 文件
