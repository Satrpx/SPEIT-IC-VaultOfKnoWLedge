"""
TODO List Web Application
基础框架 - 使用 Vibe Coding 添加功能！

当前功能:
- 查看任务列表
- 添加新任务
- 标记任务完成/未完成
- 删除任务

待添加功能 (Vibe Coding):
- 任务优先级
- 搜索和过滤
- 任务统计
- 更多 UI 优化
"""

from flask import Flask, render_template, request, jsonify
import json
import os

app = Flask(__name__)

# 数据文件
DATA_FILE = 'todos.json'

def load_todos():
    """加载任务列表"""
    if os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return []

def save_todos(todos):
    """保存任务列表"""
    with open(DATA_FILE, 'w', encoding='utf-8') as f:
        json.dump(todos, f, ensure_ascii=False, indent=2)

@app.route('/')
def index():
    """主页 - 显示任务列表"""
    return render_template('index.html')

@app.route('/api/tasks', methods=['GET'])
def get_tasks():
    """获取所有任务"""
    todos = load_todos()
    return jsonify(todos)

@app.route('/api/tasks', methods=['POST'])
def add_task():
    """添加新任务"""
    data = request.json
    todos = load_todos()
    
    new_task = {
        'id': len(todos) + 1,
        'title': data.get('title', ''),
        'completed': False
    }
    
    todos.append(new_task)
    save_todos(todos)
    
    return jsonify(new_task)

@app.route('/api/tasks/<int:task_id>', methods=['PUT'])
def toggle_task(task_id):
    """切换任务完成状态"""
    todos = load_todos()
    
    for task in todos:
        if task['id'] == task_id:
            task['completed'] = not task['completed']
            break
    
    save_todos(todos)
    return jsonify({'success': True})

@app.route('/api/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    """删除任务"""
    todos = load_todos()
    todos = [t for t in todos if t['id'] != task_id]
    save_todos(todos)
    return jsonify({'success': True})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=8001)
